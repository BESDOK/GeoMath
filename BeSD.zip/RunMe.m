
% 1 <= FNCNO <=60
load FncData
FNCNO = 1 ; set_fnc_settings(FNCNO);  out = algo_besd(fnc,[],30,dim,low,up,10e3);
